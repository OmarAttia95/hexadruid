# Internal helper functions, only used inside _core.py

def internal_logger(msg: str):
    print(f"[HexaDruid] {msg}")
