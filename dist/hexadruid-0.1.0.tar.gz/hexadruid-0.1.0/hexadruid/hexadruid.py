# hexadruid/hexadruid.py
from ._core import _HexaDruidCore

class HexaDruid(_HexaDruidCore):
    """
    Public HexaDruid interface — use this class for all user operations.
    """
    pass